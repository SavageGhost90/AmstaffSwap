# SCC Frontend

[![Netlify Status](https://api.netlify.com/api/v1/badges/2193263e-af7b-463a-ba13-ceca0aa87731/deploy-status)](https://app.netlify.com/sites/siacashcoin/deploys)

If you want to contribute to SCC Frontend, please refer to the [contributing guidelines](./CONTRIBUTING.md) of this project.

Find us on Telegram at https://t.me/SiaCashCoinChat

Contact our team to add a new syrup/farm pool to our frontend!

At SCC swap https://siacashcoin.com/swap we now support all bsc network tokens listed at https://www.coingecko.com/ and https://coinmarketcap.com/ if you would like us to publish a new token that has yet to be listed send us a pull request or contact us on Telegram and we will add it for you!


