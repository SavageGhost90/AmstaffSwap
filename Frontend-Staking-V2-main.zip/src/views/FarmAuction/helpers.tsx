// eslint-disable-next-line import/prefer-default-export
export const FORM_ADDRESS =
  'https://docs.google.com/forms/d/e/1FAIpQLScUkwbsMWwg7L5jjGjEcmv6RsoCNhFDkV3xEpRu2KcJrr47Sw/viewform'
